<?php

include("permissionapi.php");

//redireciona para api
header("Location: /api");